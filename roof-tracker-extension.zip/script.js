const CONFIG = {
    version: "1.0.0",
    validJobIdRegex: /^\d{8,9}$/,
    dayShiftSchedule: [
        { start: "13:45:00", end: "15:30:00", duration: "1:45:00", task: "TWISTER", cat: "Hipster" },
        { start: "13:30:00", end: "13:45:00", duration: "0:15:00", task: "BREAK", cat: "BREAK" },
        { start: "12:00:00", end: "13:30:00", duration: "1:30:00", task: "TWISTER", cat: "Hipster" },
        { start: "11:00:00", end: "12:00:00", duration: "1:00:00", task: "BREAK", cat: "BREAK" },
        { start: "09:15:00", end: "11:00:00", duration: "1:45:00", task: "TWISTER", cat: "Hipster" },
        { start: "09:00:00", end: "09:15:00", duration: "0:15:00", task: "BREAK", cat: "BREAK" },
        { start: "06:30:00", end: "09:00:00", duration: "2:30:00", task: "TWISTER", cat: "Hipster" }
    ],
    nightShiftSchedule: [
        { start: "03:30:00", end: "06:00:00", duration: "2:30:00", task: "TWISTER", cat: "Hipster" },
        { start: "03:15:00", end: "03:30:00", duration: "0:15:00", task: "BREAK", cat: "BREAK" },
        { start: "02:00:00", end: "03:15:00", duration: "1:15:00", task: "TWISTER", cat: "Hipster" },
        { start: "01:00:00", end: "02:00:00", duration: "1:00:00", task: "BREAK", cat: "BREAK" },
        { start: "23:45:00", end: "01:00:00", duration: "1:15:00", task: "TWISTER", cat: "Hipster" },
        { start: "23:30:00", end: "23:45:00", duration: "0:15:00", task: "BREAK", cat: "BREAK" },
        { start: "21:00:00", end: "23:30:00", duration: "2:30:00", task: "TWISTER", cat: "Hipster" }
    ]
};
// TABLE OF CONTENTS
// CONFIGURATION & DOM ELEMENTS
// TRACKER STATE MANAGEMENT
// STORAGE ENGINE
// 2. JOB FORM ACTIONS & VALIDATION
// 3. UPDATE & DELETE JOB UTILITIES
// 4. REJECT JOB PIPELINE
// 5. CLIPBOARD & SCREENSHOT PIPELINES
// 6. OVERTIME AUTOMATION
// 7. USER INITIALIZATION & SESSIONS
// 8. HISTORY TABLE
// 9. EVENT LISTENERS
// 10. UI RENDERING & DOM MUTATIONS
// 11. CSV EXPORT ENGINE
// 12. MAPS INTEGRATION
// 13. CLOSING TABS
// 14. INITIALIZATION BOOTSTRAP


//DOMS

const jobIdInputEl = document.getElementById("job-id-input");
const jobFormEl = document.getElementById("job-form");
const eJobFormEl = document.getElementById("edit-job-form");
const eJobIdInputEl = document.getElementById('edit-job-id-input');
const eJobLinkEl = document.getElementById("edit-job-link");
const eJobPointsEl = document.getElementById("edit-job-points");
const eJobStatusEl = document.getElementById("edit-job-status");
const userFormEl = document.getElementById("user-form");
const overtimeFormEl = document.getElementById("overtime-form");
const overtimeInputEl = document.getElementById("overtime-input");
const addJobBtnEl = document.getElementById("add-job-btn");
const dialogRejectCatEl = document.querySelector('.dialog-reject-cat');
const dialogRejectCat = document.getElementById('dialog-reject-cat');
const rejectJobCategoryEl = document.getElementById("reject-job-category");
const rejectJobBtnEl = document.getElementById("reject-job-btn");
const gMapsBtnEl = document.getElementById("gMaps-btn");
const cExplorerBtnEl = document.getElementById("cExplorer-btn");
const tscLinkInputEl = document.getElementById("tsc-link");
const pointsheetLinkInputEl = document.getElementById("pointsheet-link");
const searchWebBtnEl = document.getElementById("searchWeb-btn");
const closeTabsBtnEl = document.getElementById("closeTabs-btn");
const workedLunchEl = document.getElementById("lunch-ot-input");
const estPphDpEl = document.getElementById("est-pph-dp");



const openEditUserFormEl = document.getElementById("edit-user-form");
const eTechNoEl = document.getElementById("e-tech-no")
const eTscLinkInputEl = document.getElementById("e-tsc-link");
const eUserNameEl = document.getElementById("e-username")
const eUserShiftEl = document.getElementById("e-user-shift");
const ePointsheetLinkInputEl = document.getElementById("e-pointsheet-link");


const techNoEl = document.getElementById("tech-no");
const userNameEl = document.getElementById("user-name");
const userShiftEl = document.getElementById("user-shift");
const dialogSatusEl = document.querySelector('.dialog-status');


const jobLinkEl = document.getElementById("job-link");
const jobPointsEl = document.getElementById("job-points");
const jobStatusEl = document.getElementById("job-status");
const historyBodyEl = document.getElementById("history-body");
const totalPointsEl = document.getElementById("total-points");
const editUserform = document.getElementById("edit-user");
const downloadBtnEl = document.getElementById("download-btn");
const closeOvertimeBtnEl = document.getElementById("close-overtime-btn");

document.getElementById("confirm-job-btn").addEventListener("click", confirmJob);
document.getElementById("cancel-job-btn").addEventListener("click", closeJobForm);
document.getElementById("export-btn").addEventListener("click", exportToCSV);
document.getElementById("copy-btn").addEventListener("click", copyToClipboard);
document.getElementById("delete-all-btn").addEventListener("click", deleteAllTable);
document.getElementById("edit-confirm-job-btn").addEventListener("click", confirmEditJob);
document.getElementById("edit-cancel-job-btn").addEventListener("click", closeEditJobForm);
document.getElementById("copy-tsc-btn").addEventListener("click", copyTSC);
document.getElementById("cancel-user-btn").addEventListener("click", closeUserForm);
document.getElementById("edit-user").addEventListener("click", openEditUserForm);
document.getElementById("overtime-btn").addEventListener("click", openOvertimeForm);
document.getElementById("copy-overtime-btn").addEventListener("click", confirmCopyOvertime);
document.getElementById("close-overtime-btn").addEventListener("click", closeCopyOvertime);

document.getElementById("gMaps-btn").addEventListener("click", openGMaps);
document.getElementById("cExplorer-btn").addEventListener("click", searchAddressOnEagleView);


document.getElementById("confirm-user-btn").addEventListener("click", confirmAddUser);
document.getElementById("e-confirm-user-btn").addEventListener("click", confirmEditAddUser);
document.getElementById("e-delete-user-btn").addEventListener("click", deleteUser);
document.getElementById("e-cancel-user-btn").addEventListener("click", closeEditUserForm);
document.getElementById("searchWeb-btn").addEventListener("click", searchWeb);
document.getElementById("closeTabs-btn").addEventListener("click", closeTabs);
document.getElementById("shift-toggle-btn").addEventListener("click", toggleShift);


//About page
const aboutIcon = document.getElementById("about-page");
const aboutModal = document.getElementById("about-modal");
const closeModal = document.getElementById("close-modal");

const pointsContainer = document.querySelector('#dialog-pts-btn');
const pointsInput = document.querySelector('#job-points');

//Event Listeners


const screenWidth = screen.availWidth;
const windowWidth = Math.round(screen.availWidth / 3);
const windowHeight = Math.round(screen.availHeight / 1.5);
//TRACKERSTATE
const TrackerState =
{
    id: 0,
    user: null,
    jobs: [],
    totalPoints: 0,
    isRunning: false,
    currentEditId: 0,
    isReject: false,
    isWindowOpen: false,
    myTab: null,
    shiftStart: null,



    summateTotalPoints(totalSum) {
        let sum = 0;
        for (let i = 0; i < this.jobs.length; i++) {
            if (this.jobs[i].points == 0 || isNaN(this.jobs[i].points)) {
                continue;
            }
            if (this.jobs[i].status == "Rework") {
                continue;
            }
            sum += this.jobs[i].points;
        }
        this.totalPoints = sum;
        totalSum = sum;
        return totalSum;
    },

    async getJobInputDetails() {
        // 1. Query Chrome for the active tab in the currently focused window
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });

        // 2. Fallback gracefully if permissions fail or running outside of tab context
        const currentTabUrl = activeTab ? activeTab.url : "";

        const newJob ={
            id: crypto.randomUUID(),
            jobId: jobIdInputEl.value.trim(),
            link: currentTabUrl, // Injects the active page URL automatically
            points: parseFloat(jobPointsEl.value),
            status: jobStatusEl.value,
            date: new Date().toLocaleDateString(),

        };

        return newJob;
    }
}
//STORAGE 
const Storage = {
    save() {
        localStorage.setItem("myJobs", JSON.stringify(TrackerState.jobs));
        localStorage.setItem("myPoints", JSON.stringify(TrackerState.totalPoints));
        localStorage.setItem("myUser", JSON.stringify(TrackerState.user));
    },
    load() {
        return {
            user: JSON.parse(localStorage.getItem("myUser")) || null,
            jobs: JSON.parse(localStorage.getItem("myJobs")) || [],
        }
    },
    clear() {
        localStorage.clear();
    },
    clearAllJobs() {
        TrackerState.jobs = [];
        Storage.save();
    },
    clearUser() {
        TrackerState.user = null;
        Storage.save();
    },
}
const savedData = Storage.load();

// 2. JOB FORM
function openJobForm() {
    if (jobIdInputEl.value.trim() === "") return;
    jobFormEl.showModal();
    rejectJobBtnEl.style.display = "block";

}

function closeJobForm() {
    jobFormEl.close();
    jobIdInputEl.value = "";
    jobLinkEl.value = "";
    jobPointsEl.value = "";
    jobStatusEl.value = "Open";
}

function validateJobId(jobIdValue) {
    const regex = CONFIG.validJobIdRegex;
    if (regex.test(jobIdValue)) {
        return true;
    }
    else {
        return false;
    }
}
let lastConfirmTime = TrackerState.shiftStart; // set when shift starts

async function confirmJob() {

    if (!TrackerState.isReject) {
        const rawJobId = jobIdInputEl.value.trim();
        if (!validateJobId(rawJobId)) {
            alert("Invalid job Id. Please try again");
            return;
        }

        const newJob = await TrackerState.getJobInputDetails();
        const parsedPoints = parseFloat(jobPointsEl.value);
        if (isNaN(parsedPoints) || parsedPoints <= 0) {
            alert("Invalid Point Value, Please try again");
            return;
        }

        // ⏱ compute elapsed time
        const elapsedMs = Date.now() - lastConfirmTime;
        const elapsedMinutes = elapsedMs / 1000 / 60;
        newJob.timeElapsed = elapsedMinutes;

        // push once with timeElapsed included
        TrackerState.jobs.push(newJob);
        Storage.save();
        renderUI();


        // Reset marker for next job
        lastConfirmTime = Date.now();

        // clean up UI
        closeJobForm();
        jobIdInputEl.value = "";
        TrackerState.isReject = false;
        jobIdInputEl.focus();

    } else {
        // rejection branch...
        const rawJobId = jobIdInputEl.value.trim();
        const rawLink = jobLinkEl.value.trim();
        const rejectReason = rejectJobCategoryEl.value;

        if (!validateJobId(rawJobId)) {
            alert("Invalid job Id. Please try again");
            return;
        }

        const plainTextData = `${rawJobId}\nLink: ${rawLink}\n${rejectReason}`;
        const htmlData = `<strong>${rawJobId}</strong><br>Link: <a href="${rawLink}">Measurement UI</a><br>${rejectReason}`;

        await captureActiveTabAndTextToClipboard(plainTextData, htmlData);

        closeJobForm();
        resetRejectionFormState();
        TrackerState.isReject = false;
        window.location.href = "msteams://teams.microsoft.com/l/launch";
    }}


// 3. UPDATE/DELETE JOB FORMS
function confirmEditJob() {
    const eJobId= eJobIdInputEl.value.trim();
    const parsedPts = parseFloat(eJobPointsEl.value);
    if (!validateJobId(eJobId)) {
        alert("Invalid Job Id. Please Try Again")
        return;
    }
    if (isNaN(parsedPts)) {
        alert("Invalid Points. Please Try Again");
        return;
    }

    TrackerState.jobs = TrackerState.jobs.map(
        job => {
            if (job.id === TrackerState.currentEditId) {
                return {
                    ...job,
                    jobId: eJobIdInputEl.value.trim(),
                    link: eJobLinkEl.value.trim(),
                    points: parseFloat(eJobPointsEl.value),
                    status: eJobStatusEl.value

                };
            }
            return job;
        });
    Storage.save();
    renderUI();
    eJobFormEl.close();
    TrackerState.currentEditId = null;
}
function editJob(event) {
    const targetId = event.target.dataset.id;
    TrackerState.currentEditId = targetId;
    for (let i = 0; i < TrackerState.jobs.length; i++)
        if (TrackerState.jobs[i].id == targetId) {
            eJobFormEl.showModal();
            eJobIdInputEl.value = TrackerState.jobs[i].jobId;
            eJobPointsEl.value = TrackerState.jobs[i].points;
            eJobLinkEl.value = TrackerState.jobs[i].link;
            eJobStatusEl.value = TrackerState.jobs[i].status;

        }

}
function deleteJob(event) {
    const targetId = event.target.dataset.id;
    TrackerState.jobs = TrackerState.jobs.filter(job => job.id !== targetId);
    Storage.save();
    renderUI();

}
function closeEditJobForm() {
    eJobFormEl.close();

}

//4. REJECT JOB
window.rejectJobForm = function () {
    TrackerState.isReject = true;
    dialogSatusEl.style.display = "none";
    rejectJobBtnEl.style.display = "none";
    pointsContainer.style.display = "none";
    dialogRejectCatEl.style.display = 'block';
};

function resetRejectionFormState() {
    // Return form panels back to standard default visibility settings
    dialogSatusEl.style.display = "block";
    pointsContainer.style.display = "block";
    dialogRejectCatEl.style.display = 'none';

    // Clear field entries
    jobIdInputEl.value = "";
    dialogRejectCatEl.value = "";
}


// 5. CLIPBOARD FUNCTIONS
async function captureActiveTabAndTextToClipboard(plainTextPayload, htmlPayload) {
    if (typeof chrome === "undefined" || !chrome.tabs) {
        console.error("Context Error: Run within extension environment.");
        return;
    }

    try {
        // 1. Capture screenshot
        const dataUrl = await new Promise((resolve, reject) => {
            chrome.tabs.captureVisibleTab(null, { format: "png" }, (result) => {
                if (chrome.runtime.lastError) {
                    return reject(new Error(chrome.runtime.lastError.message));
                }
                resolve(result);
            });
        });

        // 2. Embed screenshot directly inside the HTML payload
        const htmlWithImage = `
                    ${htmlPayload}
                    <br>
                    <img src="${dataUrl}" style="max-width: 100%; height: auto; display: block; margin-top: 3px; border-radius: 4px;">
                `;

        // 3. Write HTML + plain text only — no separate image blob needed
        const textBlob = new Blob([plainTextPayload], { type: "text/plain" });
        const htmlBlob = new Blob([htmlWithImage], { type: "text/html" });

        await navigator.clipboard.write([
            new ClipboardItem({
                "text/plain": textBlob,
                "text/html": htmlBlob
            })
        ]);

    } catch (err) {
        console.error("Clipboard Pipeline Fault:", err.message);
        alert("Clipboard update failed: " + err.message);
    }
}
function copyToClipboard() {
    const pointLink = TrackerState.user?.pointsheetLink;
    const rows = TrackerState.jobs.map(j =>
        [j.jobId, , j.points, j.status].join("\t")
    );
    navigator.clipboard.writeText(rows.join("\n"));
    if (pointLink) {
        window.open(pointLink, 'popupWindow', 'width=800,height=600,scrollbars=yes');
    }
};

function copyTSC() {
    if (!TrackerState.user) return;
    let pastePayLoad = "";
    const liveOvertimeValue = parseFloat(overtimeInputEl.value) || 0;
    const tscLink = TrackerState.user?.tscLink;

    if (TrackerState.user?.userShift == "Day") {
        const shiftSchedule = [...CONFIG.dayShiftSchedule];

        if (liveOvertimeValue > 0) {
            const hours = Math.floor(liveOvertimeValue);
            const minutes = Math.floor((liveOvertimeValue % 1) * 60);

            // Formats the duration explicitly to match your time taken column structure
            const durationStr = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:00`;

            const calculatedEndHour = 15 + hours;
            const calculatedEndMin = 30 + minutes;
            const endStr = `${calculatedEndHour.toString().padStart(2, "0")}:${calculatedEndMin.toString().padStart(2, "0")}:00`;

            shiftSchedule.unshift({
                start: "15:30:00",
                end: endStr,
                duration: durationStr,
                task: "TWISTER",
                cat: "Hipster"
            });
        }

        pastePayLoad = compileTscPayload(shiftSchedule);
        navigator.clipboard.writeText(pastePayLoad);
    }
    else {
        const baseDate = new Date();
        const nextdate = new Date(baseDate);

        baseDate.setDate(baseDate.getDate() - 1);


        const day1str = baseDate.toLocaleDateString();
        const day2str = nextdate.toLocaleDateString();

        const shiftSchedule = CONFIG.nightShiftSchedule;

        pastePayLoad = compileTscPayload(shiftSchedule, (startHourStr) => {
            const startHour = parseInt(startHourStr.split(":")[0], 10);
            return (startHour == 0 || startHour < 12) ? day2str : day1str;
        });
        navigator.clipboard.writeText(pastePayLoad);
        alert("Copied to clipboard — paste directly into sheets.");
    }
    if (tscLink) {
        window.open(tscLink, 'popupWindow', 'width=1920,height=1080,scrollbars=yes');
    }
}
function compileTscPayload(shiftScheduleArray, dateHandlerCb) {
    const liveOvertimeValue = parseFloat(overtimeInputEl.value) || 0;
    const workedLunchChecked = workedLunchEl.checked; // ✅ use the correct element

    // Precompute the second break slot
    const breakSlots = shiftScheduleArray.filter(s => s.task === "BREAK");
    const secondBreak = breakSlots[1]; // index 1 = second break

    return shiftScheduleArray.map((slot, index) => {
        const rowDate = dateHandlerCb ? dateHandlerCb(slot.start) : new Date().toLocaleDateString();

        const baseColumns = [
            TrackerState.user.techNo,
            TrackerState.user.userName,
            TrackerState.user.userShift,
            rowDate,
            slot.start,
            slot.end,
            slot.duration,
            slot.task,
            slot.cat
        ];

        let eotField = "NO";

        // Rule 1: Overtime input → first row gets YES
        if (index === 0 && liveOvertimeValue > 0) {
            eotField = "YES";
        }

        // Rule 2: Worked Lunch checkbox → second break slot gets YES
        if (
            workedLunchChecked &&
            secondBreak &&
            slot.start === secondBreak.start &&
            slot.end === secondBreak.end
        ) {
            eotField = "YES";
        }

        baseColumns.push(eotField);
        return baseColumns.join("\t");
    }).join("\n");
}


async function writeRichLinkToClipboard(url) {
    if (!url || !url.startsWith('http')) return;
    try {
        const htmlString = `<a href="${url}">${url}</a>`;
        const textBlob = new Blob([url], { type: "text/plain" });
        const htmlBlob = new Blob([htmlString], { type: "text/html" });

        await navigator.clipboard.write([
            new ClipboardItem({
                "text/plain": textBlob,
                "text/html": htmlBlob
            })
        ]);

    } catch (err) {
        console.error("Failed to automatically write rich text link:", err);
    }
}



// 6. OVERTIME FORM
function openOvertimeForm() {
    overtimeFormEl.showModal();
}
function confirmCopyOvertime() {
        const tscLink = TrackerState.user?.tscLink;
    if (!TrackerState.user) return;
    copyTSC();
    closeCopyOvertime();
 if (tscLink) {
        window.open(tscLink, 'popupWindow','scrollbars=yes');
    }
}
function closeCopyOvertime() {
    overtimeInputEl.value = "";
    overtimeFormEl.close();

}

// 7. USER

function getNewUserInfo() {
    const username = userNameEl?.value?.trim();
    const techno = parseFloat(techNoEl?.value);
    if (!username || (Number.isNaN(techno))) return null;

    const newUser = {

        id: crypto.randomUUID(),
        userName: username,
        techNo: techno,
        userShift: userShiftEl?.value || "",
        date: new Date().toISOString().split('T')[0],
        tscLink: tscLinkInputEl.value.trim(),
        pointsheetLink: pointsheetLinkInputEl.value.trim()
    };
    return newUser;

}

function confirmAddUser() {
    const createdUser = getNewUserInfo();
    if (!createdUser) return;
    if (isNaN(createdUser.techNo)) return;
 if (createdUser.tscLink && !isValidWebUrl(createdUser.tscLink)) {
        alert("TSC link must be a valid http/https URL.");
        return;
    }
    if (createdUser.pointsheetLink && !isValidWebUrl(createdUser.pointsheetLink)) {
        alert("Pointsheet link must be a valid http/https URL.");
        return;
    }

    TrackerState.user = createdUser;
    Storage.save();
    closeUserForm();
    aboutModal.showModal();
    renderUI();

};

function closeUserForm() {
    userFormEl.close();
}
function deleteUser() {
    Storage.clearUser();
    renderUI();
    window.location.reload();
};

function openEditUserForm() {
    if (!TrackerState.user) {
        return;
    }
    getEditedUserInfo();
    openEditUserFormEl.showModal();

}

function getEditedUserInfo() {
    eUserNameEl.value = TrackerState.user.userName || "";
    eTechNoEl.value = TrackerState.user.techNo || "";
    eUserShiftEl.value = TrackerState.user.userShift || "";
    eTscLinkInputEl.value = TrackerState.user.tscLink || "";
    ePointsheetLinkInputEl.value = TrackerState.user.pointsheetLink || "";
}

function confirmEditAddUser() {
    const parsedTechNo = parseFloat(eTechNoEl.value);
    if (!eUserNameEl.value.trim() || isNaN(parsedTechNo)) {
        alert("Please provide a valid Username and Tech Number.");
        return;
    }
     if (eTscLinkInputEl.value&& !isValidWebUrl(eTscLinkInputEl.value)) {
        alert("TSC link must be a valid http/https URL.");
        return;
    }
    if (ePointsheetLinkInputEl.value&& !isValidWebUrl(ePointsheetLinkInputEl.value)) {
        alert("Pointsheet link must be a valid http/https URL.");
        return;
    }


    // Direct, explicit mutation of our state object using the input field values
    TrackerState.user = {
        ...TrackerState.user, // Preserves the original unique user ID string
        userName: eUserNameEl.value.trim(),
        techNo: parsedTechNo,
        userShift: eUserShiftEl.value || "",
        tscLink: eTscLinkInputEl.value.trim(),
        pointsheetLink: ePointsheetLinkInputEl.value.trim()
    };

    Storage.save();
    openEditUserFormEl.close(); // Target the correct modal container
    alert("User Updated Succesfully");
    renderUI();
}
function closeEditUserForm() {
    openEditUserFormEl.close();
}



//8. HISTORY TABLE
function deleteAllTable() {
    Storage.clearAllJobs();
    renderUI();
};

//9. EVENT LISTENERS

aboutIcon.addEventListener("click", () => aboutModal.showModal());
closeModal.addEventListener("click", () => aboutModal.close());

pointsContainer.addEventListener('click', (event) => {
    const button = event.target.closest('.point-btn');

    if (button) {
        // 1. Remove the active color class from whichever button currently has it
        pointsContainer.querySelectorAll('.point-btn').forEach(btn => btn.classList.remove('active'));

        // 2. Add the active color class to the button that was just clicked
        button.classList.add('active');
        const pointValue = button.dataset.category;
        pointsInput.value = pointValue;
    }
}
)
jobFormEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter")

        confirmJob();
});
// Enter key triggers Add


jobIdInputEl.addEventListener("keydown", (event) => {

    if (event.key === "Enter") {
        event.preventDefault();
        openJobForm();
        addJobBtnEl.click();
    }

});
eJobFormEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter") confirmEditJob();
});
window.addEventListener("keydown", (event) => {
    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && pressedkey === "j") {

        event.preventDefault();
        searchWebBtnEl.click();

    }
});
window.addEventListener("keydown", (event) => {
    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && pressedkey === "m") {

        event.preventDefault();
        gMapsBtnEl.click();

    }
});
window.addEventListener("keydown", (event) => {
    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && pressedkey === "k") {

        event.preventDefault();
        cExplorerBtnEl.click();

    }
});
window.addEventListener("keydown", (event) => {
    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && pressedkey == "x") {

        event.preventDefault();
        closeTabsBtnEl.click();

    }
});
window.addEventListener("keydown", (event) => {
    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && pressedkey === "d") {
        event.preventDefault();
        editUserform.style.display = "block";
        downloadBtnEl.style.display = "block";

    }
});
window.addEventListener("keydown", (event) => {
    if (event.key.toLowerCase() !== "p") return;

    if ((event.ctrlKey || event.metaKey) && event.shiftKey) {
        event.preventDefault();

        if (TrackerState.jobs.length === 0) return;

        TrackerState.jobs = TrackerState.jobs.map(job => (
            {
                ...job,
                status: "Passed"
            }
        ))
            Storage.save();
    renderUI();
    }

});

window.addEventListener("keydown", (event) => {

    const pressedkey = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key == "Enter") {
        event.preventDefault();
        window.rejectJobForm();



    }
});

addJobBtnEl.addEventListener("click", async () => {


    try {

        // Fetch data completely in-memory first
        const clipboardText = await navigator.clipboard.readText();
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        let currentUrl = tab?.url;
        // Update the form link input field
        jobLinkEl.value = currentUrl || "";



        // Only populate the job ID input if the clipboard originally had valid numeric data
        if (clipboardText) {
            const cleanJobId = clipboardText.replace(/[^0-9]/g, "");
            jobIdInputEl.value = cleanJobId;
            openJobForm();
            // Explicitly hand focus back to the input so it's ready for typing
            jobIdInputEl.focus();
        }
    } catch (err) {
        console.error("Extension Clipboard Engine Failed:", err);
        openJobForm(); // Fallback to ensure form opens even if clipboard fails
    }
});

window.addEventListener("DOMContentLoaded", () => {

    if (!TrackerState.user) {
        userFormEl.showModal();
        return;
    }
});
//Button for Rejected Jobs
rejectJobBtnEl.addEventListener("click", window.rejectJobForm);


//10. UI()
function updateStatus(event) {
    const jobId = event.target.dataset.id;
    const newStatus = event.target.value;
    for (let i = 0; i < TrackerState.jobs.length; i++) {
        if (jobId === TrackerState.jobs[i].id) {
            TrackerState.jobs[i].status = newStatus;
            Storage.save();
            updateStatusColor(event.target);
            return;
        }
    }
};

function updateStatusColor(selectEl) {
    { selectEl.className = "status-select " + selectEl.value.toLowerCase(); }
}

function highlightDuplicates() {
    const allIdCells = historyBodyEl.querySelectorAll(".cell-id");
    const seen = {};

    // First pass — count occurrences
    allIdCells.forEach(cell => {
        const id = cell.textContent.trim();
        seen[id] = (seen[id] || 0) + 1;
    });

    // Second pass — apply class to duplicates
    allIdCells.forEach(cell => {
        const id = cell.textContent.trim();
        if (seen[id] > 1) {
            cell.classList.add("duplicate-id");
        } else {
            cell.classList.remove("duplicate-id");
        }
    })
};
function updateTotalPoints() {
    totalPointsEl.textContent = "Total Points:" + TrackerState.summateTotalPoints();
};

function renderUI() {

    historyBodyEl.innerHTML = "";
    for (let i = 0; i < TrackerState.jobs.length; i++) {
        const job = TrackerState.jobs[i];
        const tr = document.createElement("tr");
        const btnEdit = document.createElement("button");
        const btnDelete = document.createElement("button");

        btnEdit.innerText = "✏️";
        btnDelete.innerText = "❌ ";

        btnEdit.dataset.id = job.id;
        btnDelete.dataset.id = job.id;

        btnDelete.addEventListener("click", deleteJob);
        btnEdit.addEventListener("click", editJob);

        btnEdit.className = "action-btn edit-btn";
        btnDelete.className = "action-btn delete-btn";
        tr.innerHTML = `
                    <td class="cell-link"></td>
                        <td class="cell-id"></td>
                        <td class="cell-points"></td>
                        <td>
                            <select data-id="${job.id}" class="status-select">
                                <option value="Open" ${job.status === "Open" ? "selected" : ""}>Open</option>
                                <option value="Passed" style="" ${job.status === "Passed" ? "selected" : ""}>Passed</option>
                                <option value="Rework" ${job.status === "Rework" ? "selected" : ""}>Rework</option>
                            </select>
                        </td>
                        <td class="cell-date">${job.date}</td>
                        <td class="cell-edit"></td>
                        <td class="cell-delete"></td>
                    
                    `;
        //XSS Prevention
        tr.querySelector(".cell-delete").appendChild(btnDelete);
        tr.querySelector(".cell-edit").appendChild(btnEdit);
        tr.querySelector(".cell-id").textContent = job.jobId;
        tr.querySelector(".cell-points").textContent = job.points;

        const anchor = document.createElement("a");
        anchor.href = job.link;
        anchor.target = "_blank";
        anchor.textContent = "Link";
        tr.querySelector(".cell-link").appendChild(anchor);

        const select = tr.querySelector(".status-select");
        select.addEventListener("change", updateStatus);

        historyBodyEl.appendChild(tr);
        updateStatusColor(select);
    }

    updateTotalPoints();
    highlightDuplicates();
    estPphDpEl.textContent = computePPH();
}



// 11. EXPORT
function exportToCSV() {
    const headers = ["Link", "Job ID", "Points", "Status", "Date"];
    const rows = TrackerState.jobs.map(j => [j.link, j.jobId, j.points, j.status, j.date]);
    const csv = [headers, ...rows].map(row => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "roof-tracker/" + new Date().toLocaleDateString() + ".csv";
    a.click();
    URL.revokeObjectURL(url);
}

//12.MAPS
async function searchWeb() {
    const address = (await navigator.clipboard.readText()).trim();
    if (!address) {
        alert("Clipboard Empty");
        return;
    }
    const sanitizedUrl = encodeURIComponent(address);
    const targetUrl = `https://www.google.com/search?q=${sanitizedUrl}`

    const queryUrl = { url: "https://www.google.com/search*" };
    const tabs = await chrome.tabs.query(queryUrl);


    if (tabs.length > 0) {
        targetTab = tabs[0];
        await chrome.tabs.update(targetTab.id, { url: targetUrl, active: true });
        await chrome.windows.update(targetTab.windowId, { focused: true })

    }
    else {

        await chrome.windows.create({
            url: targetUrl,
            type: "popup",
            left: screenWidth - windowWidth,
            top: windowWidth - Math.floor(windowWidth / 2),
            width: windowWidth,
            height: windowHeight
        });
    }
};


async function searchAddressOnEagleView() {
    try {
        const address = (await navigator.clipboard.readText()).trim();
        if (!address) {
            alert("Clipboard is empty.");
            return;
        }

        let tabs = await chrome.tabs.query({
            url: "https://explorer-internal.eagleview.com/*"
        });

        let targetTab;

        if (!tabs.length) {
            // Create new window and capture its tab
            const newWindow = await chrome.windows.create({
                url: "https://explorer-internal.eagleview.com/index.php",
                type: "popup",
                left: screenWidth - windowWidth,
                top: windowWidth - Math.floor(windowWidth / 2),
                width: windowWidth,
                height: windowHeight
            });

            targetTab = newWindow.tabs[0]; // ✅ safe   
        } else {
            targetTab = tabs[0];
        }

        if (!targetTab) {
            console.error("No EagleView tab available.");
            return;
        }

        await chrome.windows.update(targetTab.windowId, { focused: true });
        await chrome.tabs.update(targetTab.id, { active: true });

        const result = await chrome.scripting.executeScript({
            target: { tabId: targetTab.id, allFrames: true },
            func: (address) => {
                function isVisible(el) {
                    const rect = el.getBoundingClientRect();
                    return (
                        rect.width > 0 &&
                        rect.height > 0 &&
                        getComputedStyle(el).display !== "none" &&
                        getComputedStyle(el).visibility !== "hidden"
                    );
                }

                const candidates = [
                    ...document.querySelectorAll(
                        ".searchfieldpanel input, input[type='text'], input[type='search']"
                    )
                ].filter(isVisible);

                if (!candidates.length) {
                    const searchIcon = document.querySelector(".search-icon, button[aria-label='Search']");
                    if (searchIcon) {
                        searchIcon.click();
                        return { success: true, action: "Clicked search icon" };
                    }
                    return { success: false, reason: "No visible input or search icon found" };
                }

                let input = candidates[0];
                const setter = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype,
                    "value"
                )?.set;

                input.focus();
                setter ? setter.call(input, address) : (input.value = address);

                input.dispatchEvent(new Event("input", { bubbles: true }));
                input.dispatchEvent(new Event("change", { bubbles: true }));

                ["keydown", "keypress", "keyup"].forEach(type =>
                    input.dispatchEvent(
                        new KeyboardEvent(type, {
                            key: "Enter",
                            code: "Enter",
                            keyCode: 13,
                            which: 13,
                            bubbles: true
                        })
                    )
                );

                return { success: true, value: address, inputsFound: candidates.length };
            },
            args: [address]
        });


    } catch (err) {
        console.error("EagleView Search Error:", err);
    }
}

async function openGMaps() {
    try {
        const rawClipboard = await navigator.clipboard.readText();
        const cleanData = rawClipboard.trim();

        if (!cleanData) {
            alert("Clipboard context is empty.");
            return;
        }

        const sanitizedComponent = encodeURIComponent(cleanData);
        const targetUrl = `https://www.google.com/maps/place/${sanitizedComponent}`;

        // 1. Find existing Google Maps tabs
        const existingTabs = await chrome.tabs.query({ url: "https://www.google.com/maps/*" });
        const exactMatchTabs = await chrome.tabs.query({ url: targetUrl });

        // 2. If an exact match already exists → activate it
        if (exactMatchTabs.length > 0) {
            const tab = exactMatchTabs[0];
            await chrome.tabs.update(tab.id, { active: true });
            await chrome.windows.update(tab.windowId, { focused: true });
            return;
        }

        // 3. If a Maps tab exists → reuse it
        if (existingTabs.length > 0) {
            const tab = existingTabs[0];
            await chrome.tabs.update(tab.id, { url: targetUrl, active: true });
            await chrome.windows.update(tab.windowId, { focused: true });
            return;
        }

        // 4. Otherwise → open a new popup window
        await chrome.windows.create({
            url: targetUrl,
            type: "popup",
            left: screenWidth - windowWidth,
            top: windowWidth - Math.floor(windowWidth / 2),
            width: windowWidth,
            height: windowHeight
        });

        TrackerState.isWindowOpen = true;

        // 5. Auto-open Street View when thumbnail loads
        const observer = new MutationObserver(() => {
            const btn = document
                .querySelector("img[src*='thumbnail?panoid']")
                ?.closest("button");

            if (btn) {
                btn.click();
                console.log("as")
                observer.disconnect();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });

    } catch (err) {
        console.error("Extension Chrome Tabs API Fault:", err);
    }
}


//VerifyLink
function isValidWebUrl(string) {
    try {
        const url = new URL(string);
        // Explicitly check for standard secure web protocols
        return url.protocol === "https:" || url.protocol === "http:";
    } catch (_) {
        return false; // Throws an error internally if the string is invalid or malformed
    }
}
//13. CLOSING TABS
async function closeTabs() {

    const queryUrl = "https://apps.eagleview.com/measurementUi*"

    const existingTabs = await chrome.tabs.query({ url: queryUrl });

    if (existingTabs.length > 0) {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const tabsToClose = existingTabs.filter(t => t.id !== activeTab.id);

        const TabIds = tabsToClose.map(t => t.id);

        await chrome.tabs.remove(TabIds)
    }

}

//14. Start and End Shift
function toggleShift() {
    const btn = document.getElementById("shift-toggle-btn");

    // If shift is NOT running → start it
    if (!TrackerState.shiftStart) {
        const now = Date.now();

        TrackerState.shiftStart = now;
        localStorage.setItem("shiftStart", now);

        btn.classList.add("active");
        btn.textContent = "Shift Running";

        alert("Shift started");
        renderUI();
        return;
    }

    // If shift IS running → end it
    const shiftDurationMs = Date.now() - TrackerState.shiftStart;
    const hoursWorked = shiftDurationMs / 1000 / 3600;

    TrackerState.shiftStart = null;
    localStorage.removeItem("shiftStart");

    btn.classList.remove("active");
    btn.textContent = "Start Shift";

    alert(`Shift ended. Hours worked: ${hoursWorked.toFixed(2)}`);
    renderUI();
}

function computePPH() {
    if (!TrackerState.shiftStart) return "0.00";

    const hoursWorked = (Date.now() - TrackerState.shiftStart) / 1000 / 3600;

    // Prevent insane PPH at shift start
    if (hoursWorked < (1 / 60)) { // less than 1 minute
        return "0.00";
    }


    return (TrackerState.totalPoints / hoursWorked).toFixed(2);
}



// INIT & APP STARTUP
function INIT() {
    TrackerState.shiftStart = parseInt(localStorage.getItem("shiftStart")) || null;

    const btn = document.getElementById("shift-toggle-btn");
    if (TrackerState.shiftStart) {
        btn.classList.add("active");
        btn.textContent = "Shift Running";
    }
    TrackerState.user = savedData.user;
    TrackerState.jobs = savedData.jobs;
    renderUI();
    jobIdInputEl.focus();
}
INIT();
